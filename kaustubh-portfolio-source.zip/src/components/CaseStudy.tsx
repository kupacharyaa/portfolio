import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { config } from "../config";
import "./styles/CaseStudy.css";

type Project = (typeof config.projects)[number];

interface Props {
  project: Project | null;
  onClose: () => void;
}

/** A full-screen panel with the problem, approach and result for one project. */
const CaseStudy = ({ project, onClose }: Props) => {
  const closeRef = useRef<HTMLButtonElement>(null);
  const lastFocus = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!project) return;
    lastFocus.current = document.activeElement as HTMLElement;
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.documentElement.classList.add("cs-open");
    return () => {
      document.removeEventListener("keydown", onKey);
      document.documentElement.classList.remove("cs-open");
      lastFocus.current?.focus?.();
    };
  }, [project, onClose]);

  if (!project) return null;
  const cs = project.caseStudy;

  return createPortal(
    <div className="cs-backdrop" onClick={onClose} data-lenis-prevent>
      <article
        className="cs-panel"
        role="dialog"
        aria-modal="true"
        aria-labelledby="cs-title"
        onClick={(e) => e.stopPropagation()}
        onWheel={(e) => e.stopPropagation()}
        data-lenis-prevent
      >
        <button ref={closeRef} type="button" className="cs-close" onClick={onClose} aria-label="Close case study" data-cursor="disable">
          ×
        </button>
        <p className="cs-kicker">{project.category}</p>
        <h3 id="cs-title">{project.title}</h3>
        <img className="cs-cover" src={project.image} alt="" />

        <div className="cs-metrics">
          {cs.metrics.map(([value, label]) => (
            <div key={label}>
              <b>{value}</b>
              <span>{label}</span>
            </div>
          ))}
        </div>

        <section>
          <h4>The problem</h4>
          <p>{cs.problem}</p>
        </section>
        <section>
          <h4>What I did</h4>
          <ol>
            {cs.approach.map((step) => (
              <li key={step}>{step}</li>
            ))}
          </ol>
        </section>
        <section>
          <h4>The result</h4>
          <p>{cs.result}</p>
        </section>
        <a className="cs-cta" href="#contact" onClick={onClose} data-cursor="disable">
          Ask me about this project →
        </a>
      </article>
    </div>,
    document.body
  );
};

export default CaseStudy;
