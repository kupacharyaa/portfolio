import { config } from "../config";
import "./styles/CallToAction.css";

const CallToAction = () => {
  return (
    <div className="cta-section">
      <div className="cta-buttons">
        <a href="./resume.pdf" target="_blank" rel="noopener noreferrer" className="cta-btn cta-btn-play" data-cursor="disable">
          View My Résumé →
        </a>
        
        <a 
          href={config.contact.linkedin} 
          target="_blank" 
          rel="noopener noreferrer" 
          className="cta-btn cta-btn-hire"
          data-cursor="disable"
        >
          Connect on LinkedIn →
        </a>
      </div>
    </div>
  );
};

export default CallToAction;
