import "./styles/TechStackNew.css";

const toolGroups: { title: string; tools: string[] }[] = [
  { title: "Analytics & reporting", tools: ["Power BI", "SQL", "Python", "Excel · Power Query", "Tableau", "KPI dashboards"] },
  { title: "Operations & supply chain", tools: ["Lean Six Sigma", "DMAIC", "Kaizen", "Root cause analysis", "Demand planning", "Supplier scorecards", "EOQ / ROP"] },
  { title: "ERP & project management", tools: ["SAP ERP", "Jira", "MS Project", "WBS", "CPM / PERT"] },
  { title: "Modeling & simulation", tools: ["MATLAB", "Simulink", "Simscape", "SimPy (DES)", "SolidWorks", "AutoCAD"] },
];

const TechStackNew = () => {
  return (
    <div className="techstack-new">
      {/* Video Background */}
      <div className="techstack-video-container">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="techstack-video"
        >
          <source src="./video/video.webm" type="video/webm" />
        </video>
        {/* Dark Overlay */}
        <div className="techstack-overlay"></div>
      </div>

      {/* Content */}
      <div className="techstack-content">
        <h2>Toolbox</h2>
        
        <div className="toolbox">
          {toolGroups.map((g) => (
            <section className="toolbox-group" key={g.title}>
              <h3>{g.title}</h3>
              <ul>
                {g.tools.map((t) => (
                  <li key={t}>{t}</li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TechStackNew;
