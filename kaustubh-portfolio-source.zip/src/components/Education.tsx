import { useEffect } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { config } from "../config";
import "./styles/Education.css";

gsap.registerPlugin(ScrollTrigger);

const Education = () => {
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const anim = gsap.fromTo(
      ".edu-card, .edu-side > *",
      { y: 40, opacity: 0.3 },
      {
        y: 0,
        opacity: 1,
        duration: 0.8,
        stagger: 0.12,
        ease: "power3.out",
        scrollTrigger: { trigger: ".edu-section", start: "top 75%", toggleActions: "play none none none" },
      }
    );
    return () => {
      anim.scrollTrigger?.kill();
      anim.kill();
    };
  }, []);

  return (
    <div className="edu-section section-container" id="education">
      <h2>
        Education <span>&</span> credentials
      </h2>
      <div className="edu-grid">
        <div className="edu-main">
          {config.education.map((e) => (
            <article className="edu-card" key={e.degree}>
              <div className="edu-top">
                <span className="edu-period">{e.period}</span>
                <span className="edu-badge">{e.badge}</span>
              </div>
              <h3>{e.degree}</h3>
              <p className="edu-school">
                {e.school} <span>· {e.location}</span>
              </p>
              {e.coursework.length > 0 && (
                <>
                  <h4>Relevant coursework</h4>
                  <div className="edu-chips">
                    {e.coursework.map((c) => (
                      <span key={c}>{c}</span>
                    ))}
                  </div>
                </>
              )}
            </article>
          ))}
        </div>
        <aside className="edu-side">
          <div className="edu-block">
            <h4>Certifications</h4>
            <ul className="edu-certs">
              {config.certifications.map((c) => (
                <li key={c.name}>
                  <span>{c.name}</span>
                  <em className={c.status === "Certified" ? "" : "edu-progress"}>{c.status}</em>
                </li>
              ))}
            </ul>
          </div>
          <div className="edu-block">
            <h4>Leadership</h4>
            {config.leadership.map((l) => (
              <div className="edu-lead" key={l.role}>
                <b>{l.role}</b>
                <span>{l.org}</span>
                <em>{l.period}</em>
              </div>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
};

export default Education;
