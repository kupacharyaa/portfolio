import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { DRACOLoader, GLTFLoader } from "three-stdlib";
import { config } from "../config";
import { decryptBuffer } from "./Character/utils/decrypt";
import { CHARACTER_ENC_B64, b64ToBuffer } from "./Character/utils/embeddedAssets";
import "./styles/Guide.css";

type Line = { target: string; index?: number; text: string };

const reduceMotion = () =>
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;

/**
 * A small narrator: the same 3D character, framed on his head and shoulders,
 * who follows the cursor and explains each part of the page as it scrolls in.
 */
const Guide = () => {
  const canvasWrap = useRef<HTMLDivElement>(null);
  const talking = useRef(false);
  const [shown, setShown] = useState(false);
  const [closed, setClosed] = useState(false);
  const [line, setLine] = useState<Line | null>(null);
  const [typed, setTyped] = useState("");
  const [open, setOpen] = useState(false);
  const [unread, setUnread] = useState(false);
  const quiet = !open;
  const [step, setStep] = useState({ n: 0, total: config.guide.lines.length });

  // When to show the narrator: after the big character has left (desktop), or after the hero (smaller screens).
  useEffect(() => {
    const onScroll = () => {
      const desktop = window.innerWidth > 768;
      if (desktop) {
        const career = document.querySelector(".career-section");
        setShown(!!career && career.getBoundingClientRect().top < window.innerHeight * 0.75);
      } else {
        setShown(window.scrollY > window.innerHeight * 0.55);
      }
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  // Pick the line for whatever sits across the middle of the screen.
  useEffect(() => {
    const lines = config.guide.lines as Line[];
    let current = -1, raf = 0;
    const check = () => {
      raf = 0;
      const cy = window.innerHeight * 0.5, cx = window.innerWidth * 0.5;
      let found = -1;
      lines.forEach((l, i) => {
        const el = document.querySelectorAll(l.target)[l.index ?? 0];
        if (!el) return;
        const r = el.getBoundingClientRect();
        if (r.top <= cy && r.bottom >= cy && r.left <= cx + r.width * 0.25 && r.right >= cx - r.width * 0.25 && r.width > 0) found = i;
      });
      if (found !== -1 && found !== current) {
        current = found;
        setLine(lines[found]);
        setStep({ n: found + 1, total: lines.length });
      }
    };
    const onScroll = () => { if (!raf) raf = requestAnimationFrame(check); };
    const t = setInterval(check, 600); // the work row moves sideways without firing scroll on every frame
    window.addEventListener("scroll", onScroll, { passive: true });
    check();
    return () => {
      clearInterval(t);
      window.removeEventListener("scroll", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  // Type the line out, a character at a time.
  useEffect(() => {
    if (!line) return;
    if (reduceMotion()) {
      setTyped(line.text);
      return;
    }
    let i = 0;
    let hide: ReturnType<typeof setTimeout> | undefined;
    talking.current = true;
    setUnread(true);
    setTyped("");
    const id = setInterval(() => {
      i += 2;
      setTyped(line.text.slice(0, i));
      if (i >= line.text.length) {
        clearInterval(id);
        talking.current = false;
        hide = undefined;
      }
    }, 22);
    return () => {
      clearInterval(id);
      if (hide) clearTimeout(hide);
    };
  }, [line]);

  // The 3D head-and-shoulders view.
  useEffect(() => {
    const wrap = canvasWrap.current;
    if (!wrap) return;
    let disposed = false;
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "low-power" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    wrap.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    scene.add(new THREE.HemisphereLight(0xf1e8ff, 0x2a1840, 1.6));
    const key = new THREE.DirectionalLight(0xffffff, 1.6);
    key.position.set(2, 3, 5);
    scene.add(key);
    const rim = new THREE.DirectionalLight(0xc2a4ff, 2.2);
    rim.position.set(-4, 2, -3);
    scene.add(rim);
    const camera = new THREE.PerspectiveCamera(20, 1, 0.1, 200);

    const size = () => {
      const w = wrap.clientWidth, h = wrap.clientHeight;
      if (!w || !h) return;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    size();
    const ro = new ResizeObserver(size);
    ro.observe(wrap);

    let head: THREE.Object3D | null = null;
    let mixer: THREE.AnimationMixer | null = null;
    let mouse = { x: 0, y: 0 };
    const onMove = (e: MouseEvent) => {
      mouse = { x: (e.clientX / window.innerWidth) * 2 - 1, y: -(e.clientY / window.innerHeight) * 2 + 1 };
    };
    document.addEventListener("mousemove", onMove);

    (async () => {
      try {
        const buf = await decryptBuffer(b64ToBuffer(CHARACTER_ENC_B64), "Character3D#@");
        if (disposed) return;
        const loader = new GLTFLoader();
        const draco = new DRACOLoader();
        draco.setDecoderPath("./draco/");
        loader.setDRACOLoader(draco);
        loader.parse(buf, "./", (gltf) => {
          if (disposed) return;
          const ch = gltf.scene;
          // Keep only the person: hide the desk, monitor and screen glow.
          ch.traverse((o: any) => {
            if (o.name === "Plane004" || o.name === "screenlight") o.visible = false;
          });
          scene.add(ch);
          mixer = new THREE.AnimationMixer(ch);
          const intro = gltf.animations.find((c) => c.name === "introAnimation");
          if (intro) {
            const a = mixer.clipAction(intro);
            a.setLoop(THREE.LoopOnce, 1);
            a.clampWhenFinished = true;
            a.play();
            mixer.update(intro.duration);
          }
          const blink = gltf.animations.find((c) => c.name === "Blink");
          if (blink) mixer.clipAction(blink).play();
          ch.updateMatrixWorld(true);
          head = ch.getObjectByName("spine006") || null;
          const focus = new THREE.Vector3();
          if (head) head.getWorldPosition(focus);
          else new THREE.Box3().setFromObject(ch).getCenter(focus);
          focus.y += 0.2;
          camera.position.set(focus.x + 0.4, focus.y + 0.25, focus.z + 10.5);
          camera.lookAt(focus);
          draco.dispose();
        }, () => {});
      } catch {
        /* the bubble still works without the 3D head */
      }
    })();

    const clock = new THREE.Clock();
    let raf = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const dt = clock.getDelta(), t = clock.elapsedTime;
      if (mixer) mixer.update(dt);
      if (head) {
        const still = reduceMotion();
        const nod = talking.current && !still ? Math.sin(t * 9) * 0.05 : 0;
        head.rotation.y = THREE.MathUtils.lerp(head.rotation.y, mouse.x * 0.55, 0.08);
        head.rotation.x = THREE.MathUtils.lerp(head.rotation.x, -mouse.y * 0.25 + nod, 0.12);
      }
      if (wrap.offsetParent !== null) renderer.render(scene, camera);
    };
    loop();

    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      ro.disconnect();
      document.removeEventListener("mousemove", onMove);
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, []);

  const visible = shown && !closed && !!line;

  return (
    <>
      <aside
        className={`guide ${visible ? "guide-on" : ""}`}
        aria-hidden={!visible}
        aria-label="Kaustubh's guide"
      >
        <div className={`guide-bubble ${quiet ? "guide-quiet" : ""}`} aria-live="polite">
          <div className="guide-bubble-top">
            <span className="guide-name">Kaustubh</span>
            <span className="guide-step">
              {String(step.n).padStart(2, "0")} / {String(step.total).padStart(2, "0")}
            </span>
          </div>
          <p>
            {typed}
            <span className="guide-caret" aria-hidden="true" />
          </p>
          <span className="sr-only">{line?.text}</span>
        </div>
        <div
          className="guide-avatar"
          onClick={() => {
            setOpen((o) => !o);
            setUnread(false);
          }}
          role="button"
          tabIndex={0}
          aria-expanded={open}
          aria-label={open ? "Hide the guide's notes" : "Show the guide's notes for this section"}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              setOpen((o) => !o);
              setUnread(false);
            }
          }}
        >
          <div className="guide-canvas" ref={canvasWrap} />
          {!open && <span className={`guide-hint ${unread ? "guide-hint-new" : ""}`}>Walk me through</span>}
          <button
            type="button"
            className="guide-close"
            onClick={(e) => {
              e.stopPropagation();
              setClosed(true);
            }}
            aria-label="Hide the guide"
            data-cursor="disable"
          >
            ×
          </button>
        </div>
      </aside>
      {closed && shown && (
        <button type="button" className="guide-reopen" onClick={() => setClosed(false)} data-cursor="disable">
          Show guide
        </button>
      )}
    </>
  );
};

export default Guide;
