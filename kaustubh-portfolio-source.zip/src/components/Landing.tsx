import { PropsWithChildren, useEffect, useState } from "react";
import "./styles/Landing.css";
import { config } from "../config";

const ROLES = [
  ["Supply Chain", "Analyst"],
  ["Operations", "Analyst"],
  ["Systems", "Engineer"],
];

const PROOF = [
  ["35%", "cycle-time cut"],
  ["78→91%", "SLA on-time"],
  ["$750K", "inventory found"],
];

const Landing = ({ children }: PropsWithChildren) => {
  const [role, setRole] = useState(0);
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const id = setInterval(() => setRole((r) => (r + 1) % ROLES.length), 3200);
    return () => clearInterval(id);
  }, []);
  const nameParts = config.developer.fullName.split(" ");
  const firstName = nameParts[0] || config.developer.name;
  const lastName = nameParts.slice(1).join(" ") || "";

  return (
    <>
      <div className="landing-section" id="landingDiv">
        <div className="landing-container">
          <div className="landing-intro">
            <h2>Hello! I'm</h2>
            <h1>
              {firstName.toUpperCase()}
              {' '}
              <br />
              {lastName && <span>{lastName.toUpperCase()}</span>}
            </h1>
            <ul className="landing-proof" aria-label="Key results">
              {PROOF.map(([v, l]) => (
                <li key={l}>
                  <b>{v}</b>
                  <span>{l}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="landing-info">
            <h3>A</h3>
            <div className="role-swap" aria-live="off">
              <span className="role-a" key={"a" + role}>{ROLES[role][0]}</span>
              <span className="role-b" key={"b" + role}>{ROLES[role][1]}</span>
            </div>
            <span className="sr-only">Supply Chain Analyst, Operations Analyst and Systems Engineer</span>
          </div>
        </div>
        {children}
      </div>
    </>
  );
};

export default Landing;
