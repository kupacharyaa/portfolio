export const config = {
    developer: {
        name: "Kaustubh",
        fullName: "Kaustubh Upacharya",
        title: "Systems Engineering & Operations / Supply Chain Analyst",
        description: "Systems Engineering graduate student at Stevens and operations & supply chain analyst who turns data into decisions."
    },
    social: {
        email: "upacharyaak@gmail.com",
        location: "New Jersey, USA"
    },
    about: {
        title: "About Me",
        description: "I'm a Systems Engineering graduate student at Stevens Institute of Technology (M.S., GPA 3.7/4.0) and an operations and supply chain analyst who turns data into decisions with Power BI, SQL, Python and Excel, grounded in Lean Six Sigma, DMAIC and root-cause analysis. I work hands-on with requirements engineering, system architecture, V&V, trade studies and MATLAB/Simulink simulation, and I bring that rigor to operations, supply chain and project coordination."
    },
    experiences: [
        {
            position: "Operations Analyst Intern",
            company: "Teleworld Solutions",
            period: "Jun – Aug 2026",
            year: "2026",
            location: "New Jersey, USA",
            description: "Monthly Power BI dashboards for Staffing leadership.",
            highlights: [
                "Built and maintained Power BI dashboards on travel-cost trends, reimbursement cycle time and staffing headcount.",
                "Surfaced top cost drivers, outliers and approval bottlenecks in weekly and monthly summaries.",
                "Processed reimbursement requests, validating completeness and policy alignment."
            ],
            technologies: ["Power BI", "Excel", "KPI Reporting"]
        },
        {
            position: "Vehicle Systems Engineering Intern",
            company: "Engine 0 AI Systems",
            period: "Jun – Aug 2026",
            year: "2026",
            location: "Remote",
            description: "EV powertrain simulation in MATLAB/Simulink/Simscape.",
            highlights: [
                "Built a battery-operated DC-drive EV powertrain simulation in MATLAB/Simulink/Simscape.",
                "Debugged multi-domain electrical–mechanical interfaces and validated response across duty cycles.",
                "Prepared technical reports, presentations and documentation."
            ],
            technologies: ["MATLAB", "Simulink", "Simscape"]
        },
        {
            position: "Operations Analyst",
            company: "eClerx Pvt. Ltd.",
            period: "Jun 2024 – Jul 2025",
            year: "2024",
            location: "Pune, India",
            description: "Process improvement and SLA analytics.",
            highlights: [
                "Led a cross-functional Kaizen on order exceptions: 35% cycle-time reduction.",
                "Built a Power BI exception-aging dashboard on SLA compliance: on-time resolution up from 78% to 91%.",
                "Reconciled order and capacity data against SAP records before month-end close."
            ],
            technologies: ["Kaizen", "Power BI", "SAP"]
        }
    ],
    education: [
        {
            degree: "M.S. Systems Engineering",
            school: "Stevens Institute of Technology",
            location: "Hoboken, NJ",
            period: "Expected May 2027",
            badge: "GPA 3.7 / 4.0",
            coursework: ["Space Mission Design & Operations", "Operations Management", "Supply Chain Analytics", "Modeling & Simulation", "System Architecture", "Systems Integration", "Project Management of Complex Systems"]
        },
        {
            degree: "B.E. Electronics & Telecommunication Engineering",
            school: "Savitribai Phule Pune University",
            location: "Pune, India",
            period: "June 2023",
            badge: "Bachelor's",
            coursework: []
        }
    ],
    leadership: [
        { role: "Media & Event Head", org: "Graduate Consulting Club, Stevens Institute of Technology", period: "Apr 2026 – Present" }
    ],
    projects: [
        {
            id: 4,
            title: "MediCrystals: Supply Chain Analytics & Optimization",
            category: "BIA 674 · Supply Chain Analytics",
            technologies: "100-point supplier scorecard across 12 suppliers · 2,000+ SKUs · $750K in slow-moving inventory identified · EOQ/ROP, Power BI",
            image: "./images/medicrystals.png",
            description: "",
            caseStudy: {
                problem: "Find where inventory and supplier performance were costing MediCrystals money.",
                approach: [
                    "Built a 100-point supplier scorecard across 12 global suppliers.",
                    "Analyzed 2,000+ SKUs using EOQ/ROP in Power BI."
                ],
                result: "Identified $750K in slow-moving inventory and recommended safety-stock rebalancing.",
                metrics: [["$750K", "slow-moving inventory"], ["2,000+", "SKUs analyzed"], ["12", "suppliers scored"]]
            },
            link: ""
        },
        {
            id: 1,
            title: "Stevens Shuttle Optimization System",
            category: "SYS 625 · Requirements, Architecture, Trade Study",
            technologies: "20+ stakeholder needs into traceable requirements · Pugh Matrix trade study · TPMs: ≤10-min wait, ≥90% ETA accuracy, ≥95% coverage, ≥99% uptime",
            image: "./images/shuttle.png",
            description: "",
            caseStudy: {
                problem: "Design a campus shuttle concept that combines fixed routes with dynamic, on-demand routing.",
                approach: [
                    "Translated 20+ stakeholder needs into traceable requirements.",
                    "Built a functional architecture spanning demand intake, routing, dispatch and safety monitoring.",
                    "Ran a Pugh Matrix trade study with technical risk analysis and TPM development."
                ],
                result: "A cyber-physical optimization concept with measurable targets: ≤10-min wait, ≥90% ETA accuracy, ≥95% coverage and ≥99% uptime.",
                metrics: [["≤ 10 min", "wait time"], ["≥ 90%", "ETA accuracy"], ["≥ 95%", "coverage"], ["≥ 99%", "uptime"]]
            },
            link: ""
        },
        {
            id: 2,
            title: "Mars Climate Orbiter: Failure Mode & Root Cause Analysis",
            category: "SYS 611 · Failure Mode & Root Cause Analysis",
            technologies: "Root cause traced to an unhandled unit mismatch and 3 verification gaps · IEEE-formatted corrective-action report",
            image: "./images/mco.png",
            description: "",
            caseStudy: {
                problem: "Find out why the Mars Climate Orbiter mission was lost, and how to keep it from happening again.",
                approach: [
                    "Performed failure mode and root cause analysis on the interface-control process.",
                    "Traced the failure to an unhandled unit mismatch and 3 verification gaps.",
                    "Authored an IEEE-formatted corrective-action report."
                ],
                result: "A corrective action with a validation checkpoint designed to prevent the failure from recurring.",
                metrics: [["1", "root cause"], ["3", "verification gaps"], ["IEEE", "report format"]]
            },
            link: ""
        },
        {
            id: 3,
            title: "Chandrayaan-3: Mission Simulation & Reliability Analysis",
            category: "SYS 632 · Discrete-Event Simulation, V&V",
            technologies: "Multi-stage lunar mission sequence simulated and verified · reliability quantified within a 99.7% confidence interval",
            image: "./images/chandrayaan.png",
            description: "",
            caseStudy: {
                problem: "Quantify how reliably a multi-stage lunar mission sequence reaches a successful outcome.",
                approach: [
                    "Built a discrete-event simulation of the multi-stage mission sequence.",
                    "Performed verification and validation of the simulation."
                ],
                result: "Outcome reliability quantified within a 99.7% confidence interval.",
                metrics: [["99.7%", "confidence interval"], ["DES", "method"], ["V&V", "performed"]]
            },
            link: ""
        },
        {
            id: 5,
            title: "Miss Budweiser: Product Requirements & Systems Design",
            category: "SYS 650 · Requirements, FMEA, Architecture",
            technologies: "15+ functional and non-functional requirements · functional/physical/operational architecture · FMEA across 6 failure modes",
            image: "./images/budweiser.png",
            description: "",
            caseStudy: {
                problem: "Define the product requirements and system design for the Miss Budweiser project.",
                approach: [
                    "Defined 15+ functional and non-functional requirements through stakeholder analysis.",
                    "Developed functional, physical and operational architecture models.",
                    "Ran an FMEA across 6 failure modes."
                ],
                result: "Prioritized risk mitigations backed by traceable requirements and architecture.",
                metrics: [["15+", "requirements"], ["6", "failure modes"], ["3", "architecture views"]]
            },
            link: ""
        }
    ],
    contact: {
        email: "upacharyaak@gmail.com",
        linkedin: "https://www.linkedin.com/in/kaustubh-upacharya-8ab2861ab/"
    },
    guide: {
        // What the narrator says as each part of the page comes into view.
        // "target" is a CSS selector; "index" picks one of several matches.
        lines: [
            { target: ".about-section", text: "Hi, I'm Kaustubh. I'm doing my M.S. in Systems Engineering at Stevens (GPA 3.7) and I work as an operations and supply chain analyst." },
            { target: ".whatIDO", text: "My work has two sides: systems engineering, from requirements and architecture to V&V, and operations analytics with Power BI, SQL and Python." },
            { target: ".career-info-box", index: 0, text: "Summer 2026 at Teleworld Solutions: monthly Power BI dashboards on travel cost, reimbursement cycle time and headcount for Staffing leadership." },
            { target: ".career-info-box", index: 1, text: "The same summer at Engine 0: I built a battery-operated DC-drive EV powertrain in Simulink and Simscape, and debugged its electrical–mechanical interfaces." },
            { target: ".career-info-box", index: 2, text: "At eClerx I led a Kaizen that cut order-exception cycle time by 35%, and my SLA dashboard lifted on-time resolution from 78% to 91%." },
            { target: ".edu-card", index: 0, text: "My M.S. in Systems Engineering at Stevens: GPA 3.7, graduating May 2027, with coursework from space mission design to supply chain analytics." },
            { target: ".edu-card", index: 1, text: "Where it started: a B.E. in Electronics & Telecommunication from Savitribai Phule Pune University, 2023." },
            { target: ".edu-side", text: "Outside class I lead media and events for the Graduate Consulting Club, and I keep adding certifications, like INCOSE ASEP and AWS Solutions Architect." },
            { target: ".work-box", index: 0, text: "MediCrystals: 12 suppliers scored on a 100-point scale, 2,000+ SKUs analyzed and $750K of slow-moving inventory found." },
            { target: ".work-box", index: 1, text: "Stevens Shuttle: I turned 20+ stakeholder needs into traceable requirements and ran a Pugh trade study. The target: waits of 10 minutes or less." },
            { target: ".work-box", index: 2, text: "Mars Climate Orbiter: I traced the mission loss to a unit mismatch and 3 verification gaps, then wrote an IEEE corrective-action report." },
            { target: ".work-box", index: 3, text: "Chandrayaan-3: a discrete-event simulation of the lunar mission, with outcome reliability quantified at a 99.7% confidence interval." },
            { target: ".work-box", index: 4, text: "Miss Budweiser: 15+ requirements, functional, physical and operational architecture, and an FMEA across 6 failure modes." },
            { target: ".work-box", index: 5, text: "Tap \"Read the case study\" on any project to see the problem, what I did and the result." },
            { target: ".techstack-new", text: "My toolbox, grouped by how I use it: analytics, operations improvement, ERP and project management, and modeling." },
            { target: ".cta-section", text: "Want the one-page version? Open my résumé, or let's connect on LinkedIn." },
            { target: ".contact-section", text: "Thanks for scrolling with me! Write to me at upacharyaak@gmail.com. I'm based in New Jersey." }
        ]
    },
    certifications: [
        { name: "INCOSE ASEP", status: "Certified" },
        { name: "AWS Certified Solutions Architect", status: "Certified" },
        { name: "SysML Professional (v2)", status: "Certified" },
        { name: "Lean Six Sigma White Belt", status: "Certified" },
        { name: "SolidWorks CSWA", status: "In progress" }
    ],
    skills: {
        develop: {
            title: "SYSTEMS ENGINEER",
            description: "Requirements, architecture & verification",
            details: "Turning stakeholder needs into traceable requirements and system architectures, then proving them with V&V, trade studies, FMEA and MATLAB/Simulink simulation.",
            tools: ["Requirements", "Architecture", "V&V", "V-Model", "Trade Studies", "FMEA", "Interface Analysis", "Risk Analysis", "Simulink", "Simscape"]
        },
        design: {
            title: "OPERATIONS ANALYST",
            description: "Data into decisions for operations & supply chain",
            details: "Building Power BI dashboards and SQL/Python analyses on KPIs, SLAs and inventory, and running Lean Six Sigma, DMAIC and Kaizen to take cycle time out of real processes.",
            tools: ["Power BI", "SQL", "Python", "Excel", "Tableau", "SAP ERP", "Lean Six Sigma", "DMAIC", "Kaizen", "Demand Planning"]
        }
    }
};
